const jwt = require('jsonwebtoken');
const User = require('../models/User');

const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret_change_me';

async function authRequired(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;

  if (!token) {
    return res.status(401).json({ error: 'Please sign in first so we know who you are.' });
  }

  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const user = await User.findById(payload.sub);
    if (!user || !user.isActive) {
      return res.status(401).json({ error: 'That account is inactive or missing. Please sign in again.' });
    }
    req.user = {
      id: user._id,
      role: user.role,
      email: user.email,
      username: user.username,
      department: user.department,
      trustScore: user.trustScore,
    };
    next();
  } catch (err) {
    return res.status(401).json({
      error: 'Your session timed out or the token is invalid. Please sign in again.',
    });
  }
}

function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({
        error: 'Your account cannot do that. Ask an administrator if you believe this is a mistake.',
      });
    }
    next();
  };
}

function signToken(user) {
  return jwt.sign(
    {
      sub: user._id.toString(),
      role: user.role,
    },
    JWT_SECRET,
    { expiresIn: '12h' }
  );
}

module.exports = {
  authRequired,
  requireRole,
  signToken,
};

