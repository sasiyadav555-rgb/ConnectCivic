const { sendStaffOtpEmail } = require('../lib/sendStaffOtpEmail');

const OTP_TTL_MS = 10 * 60 * 1000;
const VERIFIED_TTL_MS = 8 * 60 * 60 * 1000;
const RESEND_COOLDOWN_MS = 45 * 1000;

const otpRecords = new Map();
const lastOtpSent = new Map();
const staffDeptVerified = new Map();

function userKey(req) {
  return String(req.user.id);
}

function generateOtp() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

function requireStaffDeptVerified(req, res, next) {
  if (req.user.role === 'admin') {
    return next();
  }
  const uid = userKey(req);
  const until = staffDeptVerified.get(uid);
  if (!until || until < Date.now()) {
    return res.status(403).json({
      error:
        'Please verify your email first. We sent a code to the address you used when you signed in—enter it on the department screen.',
      code: 'STAFF_OTP_REQUIRED',
    });
  }
  next();
}

async function handleSendStaffOtp(req, res) {
  try {
    const uid = userKey(req);
    const now = Date.now();
    const last = lastOtpSent.get(uid) || 0;
    if (now - last < RESEND_COOLDOWN_MS) {
      const waitSec = Math.ceil((RESEND_COOLDOWN_MS - (now - last)) / 1000);
      return res.status(429).json({
        error: `Please wait ${waitSec}s before requesting another code.`,
      });
    }

    const code = generateOtp();
    otpRecords.set(uid, { code, expiresAt: now + OTP_TTL_MS });
    lastOtpSent.set(uid, now);

    const { delivered } = await sendStaffOtpEmail(req.user.email, code);
    return res.json({
      ok: true,
      delivered,
      emailHint: maskEmailHint(req.user.email),
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({
      error: 'We could not send the email code. Please try again shortly.',
    });
  }
}

function maskEmailHint(email) {
  if (!email || !email.includes('@')) return 'your email';
  const [local, domain] = email.split('@');
  const safeLocal =
    local.length <= 2 ? `${local[0] || '*'}*` : `${local.slice(0, 2)}...`;
  return `${safeLocal}@${domain}`;
}

async function handleVerifyStaffOtp(req, res) {
  try {
    const raw = req.body && req.body.code;
    const code = raw != null ? String(raw).replace(/\s/g, '') : '';
    if (!/^\d{6}$/.test(code)) {
      return res.status(400).json({
        error: 'Please type the full six-digit code exactly as it appears in your email.',
      });
    }

    const uid = userKey(req);
    const rec = otpRecords.get(uid);
    if (!rec || rec.expiresAt < Date.now()) {
      return res.status(400).json({
        error:
          'That code is expired or we never sent one. Please tap Send the code again and wait for a fresh email.',
      });
    }
    if (code !== rec.code) {
      return res.status(400).json({
        error: 'That code does not match. Please double-check the numbers from your inbox.',
      });
    }

    otpRecords.delete(uid);
    staffDeptVerified.set(uid, Date.now() + VERIFIED_TTL_MS);
    return res.json({ ok: true });
  } catch (err) {
    console.error(err);
    return res.status(500).json({
      error: 'We could not verify that code. Please wait a moment and try again.',
    });
  }
}

module.exports = {
  requireStaffDeptVerified,
  handleSendStaffOtp,
  handleVerifyStaffOtp,
};
