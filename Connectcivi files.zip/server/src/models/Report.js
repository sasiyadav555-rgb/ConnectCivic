// models/Report.js
const mongoose = require('mongoose');

const LocationSchema = new mongoose.Schema(
  {
    street: String,
    city: String,
    state: String,
    zip: String,
    landmark: String,
    latitude: Number,
    longitude: Number,
  },
  { _id: false }
);

const ReportSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    description: { type: String, required: true },

    category: {
      type: String,
      enum: ['Roads', 'Sanitation', 'Electricity', 'Security', 'Other'],
      default: 'Other',
    },

    priority: {
      type: String,
      enum: ['Low', 'Medium', 'High'],
      default: 'Low',
    },

    status: {
      type: String,
      enum: ['Pending', 'Assigned', 'Validated', 'In Progress', 'Resolved', 'Rejected'],
      default: 'Pending',
    },

    location: LocationSchema,
    mediaUrl: String,

    supportedBy: {
      type: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
      default: [],
    },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },

    assignedDepartment: {
      type: String,
      enum: ['Roads', 'Sanitation', 'Electricity', 'Security', null],
      default: null,
    },

    assignedStaff: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Report', ReportSchema);