// routes/admin.js
const express = require('express');
const Report = require('../models/Report');
const User = require('../models/User');
const { authRequired, requireRole } = require('../middleware/auth');

const router = express.Router();

router.use(authRequired, requireRole('admin'));

/* ===== STATS ===== */
router.get('/stats', async (req, res) => {
  const total = await Report.countDocuments();

  const statuses = ['Pending', 'Assigned', 'Validated', 'In Progress', 'Resolved', 'Rejected'];
  const counts = {};

  for (let s of statuses) {
    counts[s] = await Report.countDocuments({ status: s });
  }

  res.json({
    totalReports: total,
    statusCounts: counts,
  });
});

/* ===== GET REPORTS ===== */
router.get('/reports', async (req, res) => {
  const { status, category, priority, search } = req.query;

  const filter = {};

  if (status) filter.status = status;
  if (category) filter.category = category;
  if (priority) filter.priority = priority;

  if (search) {
    filter.$or = [
      { title: new RegExp(search, 'i') },
      { description: new RegExp(search, 'i') },
    ];
  }

  const reports = await Report.find(filter)
    .sort({ createdAt: -1 })
    .populate('createdBy', 'username email trustScore')
    .populate('assignedStaff', 'username email');

  res.json(reports);
});

/* ===== UPDATE REPORT ===== */
router.patch('/reports/:id', async (req, res) => {
  const { status, assignedDepartment } = req.body;

  const report = await Report.findById(req.params.id);
  if (!report) return res.status(404).json({ error: 'Report not found' });

  if (status) report.status = status;
  if (assignedDepartment) report.assignedDepartment = assignedDepartment;

  await report.save();

  res.json(report);
});

/* ===== USERS ===== */
router.get('/users', async (req, res) => {
  const users = await User.find().select(
    'username email role department trustScore createdAt'
  );

  res.json(users);
});

module.exports = router;