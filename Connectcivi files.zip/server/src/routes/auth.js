// routes/auth.js
const express = require('express');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const { signToken, authRequired } = require('../middleware/auth');

const router = express.Router();

/* ================= SIGNUP ================= */
router.post('/signup', async (req, res) => {
  try {
    const { username, email, password, confirmPassword, role, department } = req.body;

    if (!username || !email || !password || !confirmPassword || !role) {
      return res.status(400).json({
        error: 'All fields are required.',
      });
    }

    if (password.length >= 10) {
      return res.status(400).json({
        error: 'Password must be less than 10 characters.',
      });
    }

    if (password !== confirmPassword) {
      return res.status(400).json({
        error: 'Passwords do not match.',
      });
    }

    if (!['citizen', 'staff', 'admin'].includes(role)) {
      return res.status(400).json({
        error: 'Invalid role.',
      });
    }

    const existing = await User.findOne({ email: email.toLowerCase() });
    if (existing) {
      return res.status(409).json({
        error: 'Email already registered.',
      });
    }

    const passwordHash = await bcrypt.hash(password, 10);

    const user = await User.create({
      username,
      email: email.toLowerCase(),
      passwordHash,
      role,
      department: role === 'staff' ? department : null,
    });

    const token = signToken(user);

    return res.status(201).json({
      token,
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        role: user.role,
        department: user.department,
        trustScore: user.trustScore,
      },
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Signup failed.' });
  }
});

/* ================= LOGIN (FINAL FIX) ================= */
router.post('/login', async (req, res) => {
  try {
    const { email, password, role } = req.body;

    if (!email || !password || !role) {
      return res.status(400).json({
        error: 'Email, password, and role are required.',
      });
    }

    const user = await User.findOne({ email: email.toLowerCase() });

    if (!user) {
      return res.status(401).json({
        error: 'Invalid email or password.',
      });
    }

    if (user.role !== role) {
      const displayRole = user.role === 'staff' ? 'Department Staff' : (user.role === 'admin' ? 'Administrator' : 'Citizen');
      return res.status(403).json({
        error: `Selected role does not match. This account is registered as ${displayRole}.`,
      });
    }

    const match = await bcrypt.compare(password, user.passwordHash);

    if (!match) {
      return res.status(401).json({
        error: 'Invalid email or password.',
      });
    }

    const token = signToken(user);

    return res.json({
      token,
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        role: user.role, // ✅ IMPORTANT
        department: user.department,
        trustScore: user.trustScore,
      },
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Login failed.' });
  }
});

/* ================= GET PROFILE ================= */
router.get('/me', authRequired, async (req, res) => {
  const user = await User.findById(req.user.id);

  res.json({
    id: user._id,
    username: user.username,
    email: user.email,
    role: user.role,
    department: user.department,
    trustScore: user.trustScore,
  });
});

module.exports = router;