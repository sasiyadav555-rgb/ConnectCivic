const express = require('express');
const Report = require('../models/Report');
const { authRequired, requireRole } = require('../middleware/auth');
const {
  requireStaffDeptVerified,
  handleSendStaffOtp,
  handleVerifyStaffOtp,
} = require('../middleware/staffDeptVerification');

const router = express.Router();

const DEPARTMENTS = ['Roads', 'Sanitation', 'Electricity', 'Security'];

router.get('/list', authRequired, (req, res) => {
  return res.json(DEPARTMENTS);
});

router.post(
  '/verification/send-otp',
  authRequired,
  requireRole('staff'),
  handleSendStaffOtp
);

router.post(
  '/verification/verify-otp',
  authRequired,
  requireRole('staff'),
  handleVerifyStaffOtp
);

router.use(authRequired, requireRole('staff', 'admin'));

router.get('/queue', requireStaffDeptVerified, async (req, res) => {
  try {
    const department = req.query.department || req.user.department;
    if (!department) {
      return res.status(400).json({
        error: 'Please tell us which department queue you are opening.',
      });
    }

    const reports = await Report.find({
      assignedDepartment: department,
    })
      .sort({ createdAt: -1 })
      .populate('createdBy', 'username email trustScore')
      .populate('assignedStaff', 'username email');

    return res.json(reports);
  } catch (err) {
    console.error(err);
    return res.status(500).json({
      error: 'We could not load the queue. Please try again in a moment.',
    });
  }
});

router.patch('/queue/:id', requireStaffDeptVerified, async (req, res) => {
  try {
    const { status, validate, assignToSelf } = req.body;
    const report = await Report.findById(req.params.id);

    if (!report) {
      return res.status(404).json({
        error: 'We could not find that issue—it may have been reassigned.',
      });
    }

    if (!report.assignedDepartment) {
      report.assignedDepartment = req.user.department || report.assignedDepartment;
    }

    if (assignToSelf) {
      report.assignedStaff = req.user.id;
    }

    if (validate) {
      report.status = 'Validated';
    }

    if (status) {
      report.status = status;
    }

    await report.save();

    return res.json(report);
  } catch (err) {
    console.error(err);
    return res.status(500).json({
      error: 'We could not save that update. Please give it another try.',
    });
  }
});

module.exports = router;
