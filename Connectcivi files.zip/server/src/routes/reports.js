const path = require('path');
const fs = require('fs');
const express = require('express');
const multer = require('multer');
const Report = require('../models/Report');
const User = require('../models/User');
const { authRequired, requireRole } = require('../middleware/auth');

const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dest = path.join(__dirname, '..', '..', 'uploads');
    if (!fs.existsSync(dest)) {
      fs.mkdirSync(dest, { recursive: true });
    }
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    const ext = path.extname(file.originalname);
    cb(null, `report-${uniqueSuffix}${ext}`);
  },
});

const upload = multer({ storage });

router.post(
  '/',
  authRequired,
  upload.single('media'),
  async (req, res) => {
    try {
      if (req.user.role !== 'citizen') {
        return res.status(403).json({
          error: 'Only neighbor accounts can file new reports from this screen.',
        });
      }

      const {
        title,
        description,
        category,
        priority,
        street,
        city,
        state,
        zip,
        landmark,
        latitude,
        longitude,
      } = req.body;

      if (!title || !description) {
        return res.status(400).json({
          error: 'Please add both a short title and a description so staff know what is going on.',
        });
      }

      const mediaUrl = req.file ? `/uploads/${req.file.filename}` : null;

      const report = await Report.create({
        title,
        description,
        category: category || 'Other',
        priority: priority || 'Low',
        status: 'Pending',
        location: {
          street,
          city,
          state,
          zip,
          landmark,
          latitude: latitude ? Number(latitude) : undefined,
          longitude: longitude ? Number(longitude) : undefined,
        },
        mediaUrl,
        createdBy: req.user.id,
      });

      return res.status(201).json(report);
    } catch (err) {
      console.error(err);
      return res.status(500).json({
        error: 'We could not save your report. Please try submitting it again.',
      });
    }
  }
);

router.get('/', authRequired, async (req, res) => {
  try {
    const { category, status, priority, sort = 'newest', createdBy } = req.query;
    const filter = {};

    if (category) filter.category = category;
    if (status) filter.status = status;
    if (priority) filter.priority = priority;
    if (createdBy) filter.createdBy = createdBy;

    let query = Report.find(filter).populate('createdBy', 'username email trustScore');

    if (sort === 'newest') {
      query = query.sort({ createdAt: -1 });
    } else if (sort === 'oldest') {
      query = query.sort({ createdAt: 1 });
    }

    const reports = await query.exec();
    return res.json(reports);
  } catch (err) {
    console.error(err);
    return res.status(500).json({
      error: 'We could not load the report list. Please refresh in a moment.',
    });
  }
});

router.get('/mine', authRequired, async (req, res) => {
  try {
    const reports = await Report.find({ createdBy: req.user.id }).sort({
      createdAt: -1,
    });
    return res.json(reports);
  } catch (err) {
    console.error(err);
    return res.status(500).json({
      error: 'We could not load your personal reports right now—please try again shortly.',
    });
  }
});

router.post('/:id/support', authRequired, async (req, res) => {
  try {
    if (req.user.role !== 'citizen') {
      return res.status(403).json({
        error: 'Only signed-in neighbors can tap support on a report.',
      });
    }

    const report = await Report.findByIdAndUpdate(
      req.params.id,
      { $addToSet: { supportedBy: req.user.id } },
      { new: true }
    ).populate('createdBy', 'username email trustScore');

    if (!report) {
      return res.status(404).json({ error: 'We could not find that report anymore. It may have been removed.' });
    }

    return res.json(report);
  } catch (err) {
    console.error(err);
    return res.status(500).json({
      error: 'We could not record your support. Please give it another try.',
    });
  }
});

router.patch(
  '/:id/status',
  authRequired,
  requireRole('admin', 'staff'),
  async (req, res) => {
    try {
      const { status, assignedDepartment, assignedStaffId } = req.body;

      const report = await Report.findById(req.params.id);
      if (!report) {
        return res.status(404).json({ error: 'We could not find that report anymore. It may have been removed.' });
      }

      if (status) {
        report.status = status;
      }
      if (assignedDepartment) {
        report.assignedDepartment = assignedDepartment;
      }
      if (assignedStaffId) {
        const staff = await User.findById(assignedStaffId);
        if (!staff || staff.role !== 'staff') {
          return res.status(400).json({
            error: 'That staff member is not valid. Please pick someone else.',
          });
        }
        report.assignedStaff = staff._id;
        report.assignedDepartment = staff.department || report.assignedDepartment;
      }

      await report.save();

      if (['Validated', 'Resolved'].includes(report.status)) {
        const creator = await User.findById(report.createdBy);
        if (creator) {
          creator.trustScore = Math.min(100, (creator.trustScore || 50) + 2);
          await creator.save();
        }
      }

      return res.json(report);
    } catch (err) {
      console.error(err);
      return res.status(500).json({
        error: 'We could not update that report. Please try again in a little while.',
      });
    }
  }
);

module.exports = router;

